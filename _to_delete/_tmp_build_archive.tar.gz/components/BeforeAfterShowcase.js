import Reveal from "./Reveal";
import BeforeAfterSlider from "./BeforeAfterSlider";

// Tres comparaciones antes/después reales, con la misma foto y el mismo
// encuadre en cada par (nada de "antes" y "después" de escenas distintas
// forzadas a verse como una sola). Los títulos describen el tipo de
// trabajo, no un cliente o dirección inventados — estas son fotos de
// referencia, no un proyecto específico ya facturado.
const PAIRS = [
  {
    title: "Drywall Patch & Repaint",
    beforeUrl: "/hero/before-after-wall-repair-before.jpg",
    afterUrl: "/hero/before-after-wall-repair-after.jpg",
  },
  {
    title: "Baseboard & Trim Repair",
    beforeUrl: "/hero/before-after-trim-repair-before.jpg",
    afterUrl: "/hero/before-after-trim-repair-after.jpg",
  },
  {
    title: "Exterior Window Trim Repair",
    beforeUrl: "/hero/before-after-window-repair-before.jpg",
    afterUrl: "/hero/before-after-window-repair-after.jpg",
  },
];

export default function BeforeAfterShowcase({ location }) {
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {PAIRS.map((p, i) => (
        <Reveal key={p.title} delay={i * 90}>
          <BeforeAfterSlider title={p.title} location={location} beforeUrl={p.beforeUrl} afterUrl={p.afterUrl} height="h-72" />
        </Reveal>
      ))}
    </div>
  );
}
