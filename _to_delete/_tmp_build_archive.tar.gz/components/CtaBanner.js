import Link from "next/link";
import Reveal from "./Reveal";
import { IconCheck } from "./Icons";

// Banner de foto completa entre secciones de texto — el "respiro visual"
// que separa el proceso (arriba) de por qué elegirlos (abajo) en vez de
// otro bloque blanco más. object-position fija en el centro-alto de la
// habitación para que el recorte nunca corte la cama/ventana en móvil.
export default function CtaBanner({ image, eyebrow, title, text, ctaHref = "/estimate", ctaLabel = "Get a Free Estimate", points = [] }) {
  return (
    <section className="relative isolate overflow-hidden bg-navy-dark py-28 sm:py-36">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={image}
        alt=""
        loading="lazy"
        decoding="async"
        className="absolute inset-0 -z-20 h-full w-full object-cover object-[50%_30%]"
      />
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-navy-dark/92 via-navy-dark/70 to-navy-dark/35" />

      <div className="relative mx-auto max-w-6xl px-6">
        <Reveal className="max-w-lg">
          {eyebrow && <div className="eyebrow mb-3 text-gold">{eyebrow}</div>}
          <h2 className="mb-5 font-display text-[clamp(2rem,4.2vw,3.2rem)] font-bold uppercase leading-[1.02] text-white">
            {title}
          </h2>
          {text && <p className="mb-7 text-[15px] leading-relaxed text-white/75">{text}</p>}
          {points.length > 0 && (
            <ul className="mb-8 flex flex-col gap-2.5">
              {points.map((p) => (
                <li key={p} className="flex items-center gap-2.5 text-sm font-semibold text-white/90">
                  <IconCheck className="h-4 w-4 shrink-0 text-gold" />
                  {p}
                </li>
              ))}
            </ul>
          )}
          <Link href={ctaHref} className="btn-primary">{ctaLabel}</Link>
        </Reveal>
      </div>
    </section>
  );
}
