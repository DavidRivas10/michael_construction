"use client";

import Link from "next/link";
import Reveal from "./Reveal";
import { IconArrowRight, IconBrush, IconHouse, IconWrench } from "./Icons";

// Grid editorial tipo "bento" — una tarjeta grande y cuatro más chicas de
// distinto tamaño, no cinco cajas idénticas en fila. Cubre las cinco
// especialidades que Michael ofrece (dos de pintura, tres de reparación)
// con su propia fotografía real, sin tocar el modelo de datos de
// "services" que usa la pestaña de arriba (esa sigue viniendo de
// Supabase/admin) — esta sección es puramente de presentación.
const ITEMS = [
  {
    area: "big",
    title: "Exterior Painting",
    text: "Siding, trim, and facades — prepped, primed and finished to hold up through every season.",
    img: "/hero/service-exterior-painting-2.jpg",
    icon: IconHouse,
    href: "/services",
  },
  {
    area: "int",
    title: "Interior Painting",
    text: "Walls, ceilings, trim and cabinets, with clean lines and even coverage.",
    img: "/hero/service-interior-painting-1.jpg",
    icon: IconBrush,
    href: "/services",
  },
  {
    area: "rep",
    title: "Home Repairs",
    text: "The fixes most contractors skip — handled by the same crew that paints your home.",
    img: "/hero/service-home-repairs-1.jpg",
    icon: IconWrench,
    href: "/services",
  },
  {
    area: "extrep",
    title: "Exterior Repairs",
    text: "Rotted trim, damaged siding, porch columns — replaced and sealed properly.",
    img: "/hero/service-exterior-repairs-2.jpg",
    icon: IconWrench,
    href: "/services",
  },
  {
    area: "intrep",
    title: "Interior Repairs",
    text: "Drywall patches, baseboards, and trim carpentry — finished so the repair disappears.",
    img: "/hero/service-interior-repairs-1.jpg",
    icon: IconWrench,
    href: "/services",
  },
];

function Tile({ item, className = "" }) {
  const Icon = item.icon;
  return (
    <Link
      href={item.href}
      className={`group relative flex min-h-[220px] flex-col justify-end overflow-hidden rounded-sm ${className}`}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={item.img}
        alt=""
        loading="lazy"
        decoding="async"
        className="absolute inset-0 h-full w-full scale-100 object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-[1.06]"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-navy-dark/92 via-navy-dark/35 to-transparent transition-colors duration-500 group-hover:from-navy-dark/95" />
      <div className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur-sm transition-transform duration-300 group-hover:scale-110 group-hover:bg-gold group-hover:text-charcoal">
        <Icon className="h-4 w-4" />
      </div>
      <div className="relative p-5 sm:p-6">
        <h3 className="font-display text-xl font-bold uppercase leading-tight text-white sm:text-2xl">
          {item.title}
        </h3>
        <p className="mt-1.5 max-w-xs translate-y-1 text-[13px] leading-relaxed text-white/0 opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:text-white/80 group-hover:opacity-100 sm:text-[13.5px]">
          {item.text}
        </p>
        <div className="mt-3 flex items-center gap-1.5 text-[11.5px] font-bold uppercase tracking-wide text-gold opacity-90">
          Explore <IconArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
        </div>
      </div>
    </Link>
  );
}

export default function SpecialtiesGrid() {
  return (
    <div className="specialties-grid">
      {ITEMS.map((item, i) => (
        <Reveal key={item.area} delay={i * 70} className={`specialty-${item.area}`}>
          <Tile item={item} className="h-full" />
        </Reveal>
      ))}

      <style jsx>{`
        .specialties-grid {
          display: grid;
          grid-template-columns: 1fr;
          gap: 1rem;
        }
        .specialties-grid :global(.reveal) {
          height: 100%;
        }
        @media (min-width: 640px) {
          .specialties-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }
        @media (min-width: 1024px) {
          .specialties-grid {
            grid-template-columns: repeat(3, 1fr);
            grid-template-rows: repeat(3, 220px);
            grid-template-areas:
              "big big int"
              "big big rep"
              "extrep intrep intrep";
            gap: 1.1rem;
          }
          .specialty-big { grid-area: big; }
          .specialty-int { grid-area: int; }
          .specialty-rep { grid-area: rep; }
          .specialty-extrep { grid-area: extrep; }
          .specialty-intrep { grid-area: intrep; }
        }
      `}</style>
    </div>
  );
}
